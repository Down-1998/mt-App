<template>
    <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item>北京美团</el-breadcrumb-item>
        <el-breadcrumb-item>金刚山火锅</el-breadcrumb-item>
    </el-breadcrumb>
</template>
<script>
  // {{$store.state.position}}
  // {{$store.state.position}}{{$route.params.name}}
export default {

}
</script>



